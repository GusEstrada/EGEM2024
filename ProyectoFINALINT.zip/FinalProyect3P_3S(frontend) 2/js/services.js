function flipCard(card) {
    card.classList.toggle('flipped');
} 